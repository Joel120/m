<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'db1434712_w');

/** MySQL database username */
define('DB_USER', 'u1434712_Joel');

/** MySQL database password */
define('DB_PASSWORD', 'Gracia_ruth(2000)');

/** MySQL hostname */
define('DB_HOST', 'mysql2776int.cp.blacknight.com');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'yl:[R)WSf:ywe`dzP)[s>Q{H?#[r%WbM_]#|Gg[+{P&=uT_L5n5w$P!au`rRK.fy');
define('SECURE_AUTH_KEY',  'o4lrlXNYj>_Vm1Z-D#1e[jKZ4IIcW=<kVik`(s@%3h4QP]R(q~b5p&/1Xu-zKC=8');
define('LOGGED_IN_KEY',    '@j~}@.<e>{{/S8ft$YO3F@)A#Fa)IXciySH~S,zx,A-/]+b-lo?t2a8]xa<sPz_j');
define('NONCE_KEY',        'g*0lwFU8:wHvbPE_nrRD,Kk])Tq5D[}|)y7Qb;*e7PJnMDfx:?r2NaEw-NLkmjWl');
define('AUTH_SALT',        'fT!3?r)nL,]ax.?Y>vH0~sf5~,7NbJ2@nJVrD.U.1QkzLp|?}C^bgvJJi?^LjG+J');
define('SECURE_AUTH_SALT', 'iAL*#S|sK#^4.=IqVDSoe{K60l4Dvyq`X:Bd1<=p1UUhww,cn<xP8:I%`&|Khgow');
define('LOGGED_IN_SALT',   '!|*hfOiJC}Z}N|(N<a&5urYpyj:gYx3a8xD!^7X%d;ympS:`edJ*0)QkmNDF;$a7');
define('NONCE_SALT',       'CFb *H-5N7hrtJi&N+n%?Yv6%fkIs{8E70NpFB:PR?@uo,{WU.a< 2{YI}OlimRv');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
