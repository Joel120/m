This folder contains data to be placed to customer's apache websites.
