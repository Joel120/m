<?php
header("Content-Type: text/html; charset=utf-8");
$hostname = $_SERVER["HTTP_HOST"];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <meta name="viewport" content="width=device-width, user-scalable=no">
        <title></title>
        <link href="http://i.cdnpark.com/themes/assets/style.css" rel="stylesheet" type="text/css" media="screen" />
        <link href="http://i.cdnpark.com/themes/registrar/style_blacknight.css" rel="stylesheet" type="text/css" media="screen" />
        <script type="text/javascript">document.write('<script src="http://parkingcrew.net/jsparkcaf.php?regcn=868660&_v=2&_h=' + encodeURIComponent('<?php echo $hostname ?>') + '&_t=' + (new Date().getTime()) + '" type="text/javascript"></scr' + 'ipt>');</script>
        <!--<script type="text/javascript">document.write('<script src="http://parkingcrew.net/jsparkcaf.php?regcn=868660&_v=2&_h=' + encodeURIComponent('blacknightwhoisprotect.com') + '&_t=' + (new Date().getTime()) + '" type="text/javascript"></scr' + 'ipt>');</script>-->
</head>
<body>

        <div id="wrapper">

                <div id="twoclick" style="display: none;">
                <div id="holder">
                                <div id="header">
                                        <div class="width">
                                                <div id="logo">
                                                        <a href="//www.blacknight.com/"><img src="http://i.cdnpark.com/themes/registrar/images/logo_blacknight.jpg"></a>
                                                </div>
                                                <h1 id="domaintitle"><a href="#">&nbsp;</a></h1>
                                        </div>
                                </div><!--header-->
                                <div id="main" class="width">
                                        <div class="content">
                                                <div id="tc_holder1" class="tcblock"></div>
                                                <div class="fix"></div>
                                        </div>
                                        <div id="form"></div>
                                </div><!--main-->
                        </div>
                </div><!--twoclick-->






                <div id="oneclick" style="display: none">
                        <div id="header">
                                <div class="width">
                                        <div id="logo">
                                                <a href="//www.blacknight.com/"><img src="http://i.cdnpark.com/themes/registrar/images/logo_blacknight.jpg"></a>
                                        </div>
                                        <h1 id="domaintitle"><a href="#">&nbsp;</a></h1>
                                </div>
                        </div><!--header-->
                        <div id="main" class="width">
                                <div id='ads'></div>
                                <div id="sidebar"></div>
                                <div class="fix"></div>
                                <div id="form"></div>
                        </div><!--main-->
                </div><!--onelick-->

        </div><!--wrapper-->
        <div style="clear: both;"></div>
        <div id="footer" class="width">
                2014 Copyright. All Rights Reserved. <br/><br/>
                The Sponsored Listings displayed above are served automatically by a third party. Neither Parkingcrew nor the domain owner maintain any relationship with the advertisers. In case of trademark issues please contact the domain owner directly (contact information can be found in whois).<br/><br/><a onclick="showPolicy();" href="javascript:void(0);">Privacy Policy</a>
        </div>
<script>
        function showPolicy(){policywnd = window.open('http://www.parkingcrew.net/privacy_german.html','pcrew_policy','width=890,height=330,left=200,top=200,menubar=no,status=yes,toolbar=no');policywnd.focus();}
</script>
</body>
</html>



